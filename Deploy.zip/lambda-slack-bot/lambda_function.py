import os
import logging
from slack_bolt import App
from slack_bolt.adapter.aws_lambda import SlackRequestHandler

# Set up logging for AWS CloudWatch
SlackRequestHandler.clear_all_log_handlers()
logging.basicConfig(format="%(asctime)s %(message)s", level=logging.DEBUG)

# Initialize the Slack app
# process_before_response=True is REQUIRED for AWS Lambda to work properly
app = App(
    token=os.environ.get("SLACK_BOT_TOKEN"),
    signing_secret=os.environ.get("SLACK_SIGNING_SECRET"),
    process_before_response=True 
)

# 1. Listen for the /ec2 command
@app.command("/ec2")
def handle_ec2_command(ack, body, client):
    ack() # Tell Slack "I received the command!" immediately

    # Open the Modal (Form)
    client.views_open(
        trigger_id=body["trigger_id"],
        view={
            "type": "modal",
            "callback_id": "ec2_provision_modal",
            "title": {"type": "plain_text", "text": "Provision EC2"},
            "submit": {"type": "plain_text", "text": "Create Instance"},
            "blocks": [
                {
                    "type": "input",
                    "block_id": "instance_name_block",
                    "element": {"type": "plain_text_input", "action_id": "instance_name"},
                    "label": {"type": "plain_text", "text": "Instance Name"}
                },
                {
                    "type": "input",
                    "block_id": "instance_type_block",
                    "element": {
                        "type": "static_select",
                        "action_id": "instance_type",
                        "options": [
                            {"text": {"type": "plain_text", "text": "t2.micro (Free Tier)"}, "value": "t2.micro"},
                            {"text": {"type": "plain_text", "text": "t3.micro"}, "value": "t3.micro"}
                        ]
                    },
                    "label": {"type": "plain_text", "text": "Instance Type"}
                }
            ]
        }
    )

# 2. Listen for the form submission
@app.view("ec2_provision_modal")
def handle_view_submission(ack, body, client, view):
    ack() # Tell Slack "I received the form submission!"

    # Extract the inputs
    user_id = body["user"]["id"]
    instance_name = view["state"]["values"]["instance_name_block"]["instance_name"]["value"]
    instance_type = view["state"]["values"]["instance_type_block"]["instance_type"]["selected_option"]["value"]

    # We will add the AWS Boto3 code here in the next step!
    # For now, let's just send a DM confirming we got the data.
    client.chat_postMessage(
        channel=user_id,
        text=f"Got it! I am simulating provisioning your EC2 instance `{instance_name}` of type `{instance_type}`..."
    )

# 3. The AWS Lambda Handler
def lambda_handler(event, context):
    slack_handler = SlackRequestHandler(app=app)
    return slack_handler.handle(event, context)